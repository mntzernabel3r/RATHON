# Languages  - اللغات


| Code الكود | Language اللغة | Translated المترجمة | Remaining باقي |
|----|-------|-------|---|
| en | English [English] | 0 | 0 |
| ar | Arabic [العربية] | 0 | 0 |

### Note

- If Strings are not present, Google Translation will be used to Translate them at time of Usage.
<br><br>
• you can make pull requests to thise repo or send translated file on https://t.me/R0r77
