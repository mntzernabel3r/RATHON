python3 -m jmub
